#include <iostream>
#include <regex>
#include <string>

#include "./headers/ping.h"
#include "./headers/db.h"
#include "./headers/multiple_scans.h"
#include "./headers/main.h"

bool isValidIpAddress(const std::string &ipAddress) {
    const std::regex pattern(
        R"((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))");

    return std::regex_match(ipAddress, pattern);
}

bool checkIfIPUsed(const std::string &ipAddress, const std::vector<std::string> &usedIPs) {
    return std::find(usedIPs.begin(), usedIPs.end(), ipAddress) != usedIPs.end();
}

void deleteIP(std::string ipAddress, std::vector<std::string> &usedIPs) {
    usedIPs.erase(std::remove(usedIPs.begin(), usedIPs.end(), ipAddress), usedIPs.end());
}

void exitProgram(){
    exit(0);
}

int portNumber;

int main(int argc, char *argv[]) {
    std::cout << "Select IP address: ";
    std::string ipAddress;
    std::cin >> ipAddress;
    if (!isValidIpAddress(ipAddress)) {
        std::cout << "It's not a valid IP address." << std::endl;
        return 1;
    }

    std::cout << "Selected target: " << ipAddress << std::endl;
    std::string possiblePorts;
    std::cout << "Ports: ";
    std::cin >> possiblePorts;
    if (possiblePorts.find(',') != std::string::npos) {
        std::vector<int> numbers;
        std::stringstream ss(possiblePorts);
        std::string token;
        while (std::getline(ss, token, ',')) {
            numbers.push_back(std::stoi(token));
        }
        std::cout << "Individual ports selected: ";
        for (const auto &num : numbers) {
            std::cout << num << " ";
        }
        std::cout << std::endl;
        int *heapNumbers = new int[numbers.size()];
        for (size_t i = 0; i < numbers.size(); ++i) {
            if (numbers[i] > 65536 || numbers[i] < 0){
                std::cout << "Port number must be in the range 0-65535." << std::endl;
            }
            heapNumbers[i] = numbers[i];
        }
        startTheInitialScanWithMentionedPorts(ipAddress, heapNumbers, numbers.size());

        delete[] heapNumbers;
    }else{
        portNumber = std::stoi(possiblePorts);
        if (portNumber < 0 || portNumber > 65536){
            std::cerr << "Port number must be in the range 0-65535." << std::endl;
            return 1;
        }
        std::cout << "Number of ports selected: " << portNumber << std::endl;
        startTheInitialScan(ipAddress, portNumber);
    }
    saveTheFirstIP(ipAddress);

    std::cout << std::endl << "Scanning complete.\nThe output has been saved to a local database.\nDo you wish to scan again? [Y/N]:"; 
    char userChoice;
    std::cin >> userChoice;
    switch (userChoice) {
        case 'Y':
        case 'y':
            multipleScansInterface();
            break;
        case 'N':
        case 'n':
            std::cout << "Exiting...\n";
            deleteDatabase();
            Globals::instance().leaveAndRet();
            break;
        default:
            std::cout << "Invalid input. Please enter either Y or N." << std::endl;
            deleteDatabase();
            Globals::instance().leaveAndRet();
    }

    return 0;
}
