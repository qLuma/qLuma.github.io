#include "./headers/db.h"
#include "./headers/ping.h"
#include "./headers/multiple_scans.h"
#include "./headers/main.h"

#include <sqlite3.h>
#include <random>
#include <iostream>
#include <string.h>
#include <cstdio>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <algorithm>

uint16_t *numbers[15];

void getNumberOfPorts(const char* ports, int& totalPorts, int& closedPorts, int& openPorts) {

    totalPorts = 0;
    closedPorts = 0;
    openPorts = 0;

    std::istringstream iss(ports);
    std::string token;

    while (std::getline(iss, token, ',')) {
        if (token.find("closed") != std::string::npos) {
            closedPorts++;
        } else {
            openPorts++;
        }

        totalPorts++;
    }
}

void getNumbers(const char* ports, std::vector<uint16_t>& numbers) {
    std::istringstream iss(ports);
    std::string token;

    while (std::getline(iss, token, ',')) {
        size_t pos;
        if ((pos = token.find_first_not_of("0123456789")) == std::string::npos || token.find("closed") == 0) {
            size_t offset = token.find_first_of("0123456789");
            if (offset != std::string::npos) {
                numbers.push_back(static_cast<uint16_t>(std::stoi(token.substr(offset))));
            }
        }
    }
}

std::string generateRandomString(int length) {
    const std::string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    std::mt19937 generator(std::random_device{}());
    std::uniform_int_distribution<int> distribution(0, charset.size() - 1);
    std::string result;
    for (int i = 0; i < length; ++i) {
        result += charset[distribution(generator)];
    }
    return result;
}

static int callback(void *NotUsed, int argc, char **argv, char **azColName) {
    for (int i = 0; i < argc; i++) {
        std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
    }
    std::cout << "----------------------------------------" << std::endl;
    return 0;
}

void createDatabase(){
    /*
    std::string randomString = generateRandomString(8);
    filename = "localdb_" + randomString + ".sqlite3";
    */
    sqlite3 *db;
    int con;
    char *zErrMsg = 0;
    const char *sql;

    con = sqlite3_open(Globals::instance().filename.c_str(), &db);

    sql = "CREATE TABLE SCANS(" \
        "ID INTEGER PRIMARY KEY AUTOINCREMENT   NOT NULL," \
        "IP     TEXT    NOT NULL," \
        "PORTS  TEXT    DEFAULT NULL );";
    
    con = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
    if (con) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    sqlite3_close(db);
    Globals::instance().databaseAlreadyExists = 1;
}

std::vector<bool> checkMinimalDatabaseID(15, false);
void initDatabase(const std::string& ipAddress){
    
    if (Globals::instance().databaseAlreadyExists == 0)
        createDatabase();
    sqlite3 *db;
    int con;
    char *zErrMsg = 0;
    const char *sql;
    con = sqlite3_open(Globals::instance().filename.c_str(), &db);
    sqlite3_stmt *stmt;
    const char *insert_sql = "INSERT INTO SCANS (ID, IP) VALUES (?, ?)";
    con = sqlite3_prepare_v2(db, insert_sql, -1, &stmt, NULL);

    auto it = std::find(checkMinimalDatabaseID.begin(), checkMinimalDatabaseID.end(), false);
    if (it != checkMinimalDatabaseID.end()){
        int minIndex = std::distance(checkMinimalDatabaseID.begin(), it);
        sqlite3_bind_int(stmt, 1, minIndex);
        checkMinimalDatabaseID[minIndex] = true;
    }

    if (con != SQLITE_OK) {
        std::cerr << "Preparation failed: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    sqlite3_bind_text(stmt, 2, ipAddress.c_str(), -1, SQLITE_STATIC);
    
    con = sqlite3_step(stmt);
    if (con != SQLITE_DONE) {
        std::cerr << "Execution failed: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    sqlite3_finalize(stmt);

    sqlite3_close(db);
    
}

void deleteDatabase(){

    if (std::remove(Globals::instance().filename.c_str()) != 0) {
        std::cerr << "Error deleting file" << std::endl;
    } else {
        std::cout << "Deleted the local database..." << std::endl;
    }
}

void includeInDatabase(const std::string& ipAddress, int port, int closed){
    sqlite3 *db;
    char *zErrMsg = 0;
    int con;
    con = sqlite3_open(Globals::instance().filename.c_str(), &db);
    if (con) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    const char *select_sql = "SELECT PORTS FROM SCANS WHERE IP = ?";
    sqlite3_stmt *stmt;
    con = sqlite3_prepare_v2(db, select_sql, -1, &stmt, NULL);

    if (con != SQLITE_OK) {
        std::cerr << "Preparation failed: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    sqlite3_bind_text(stmt, 1, ipAddress.c_str(), -1, SQLITE_STATIC);
    while ((con = sqlite3_step(stmt)) == SQLITE_ROW) {
        if (sqlite3_column_text(stmt, 0) != NULL) {
            std::string ports(reinterpret_cast<const char *>(sqlite3_column_text(stmt, 0)));
            ports += ",";
            if (closed == 1)
                ports += "closed";
            ports += std::to_string(port);

            const char *updateSql = "UPDATE SCANS SET PORTS = ? WHERE IP = ?";
            sqlite3_stmt *updateStmt;
            con = sqlite3_prepare_v2(db, updateSql, -1, &updateStmt, NULL);

            if (con != SQLITE_OK) {
                std::cerr << "Update Preparation failed: " << sqlite3_errmsg(db) << std::endl;
                deleteDatabase();
                Globals::instance().leaveAndRet();
            }

            sqlite3_bind_text(updateStmt, 1, ports.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_text(updateStmt, 2, ipAddress.c_str(), -1, SQLITE_STATIC);

            con = sqlite3_step(updateStmt);
            if (con != SQLITE_DONE) {
                std::cerr << "Insert Execution failed: " << sqlite3_errmsg(db) << std::endl;
                deleteDatabase();
                Globals::instance().leaveAndRet();
            } 
            sqlite3_finalize(updateStmt);
            
        } else {
            
            std::string postString = std::to_string(port);
            if (closed == 1)
                postString = "closed" + std::to_string(port);
                
            const char *updateSql2 = "UPDATE SCANS SET PORTS = ? WHERE IP = ?";
            sqlite3_stmt *updateStmt2;
            con = sqlite3_prepare_v2(db, updateSql2, -1, &updateStmt2, NULL);

            if (con != SQLITE_OK) {
                std::cerr << "Update Preparation failed: " << sqlite3_errmsg(db) << std::endl;
                deleteDatabase();
                Globals::instance().leaveAndRet();
            }

            sqlite3_bind_text(updateStmt2, 1, postString.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_text(updateStmt2, 2, ipAddress.c_str(), -1, SQLITE_STATIC);

            con = sqlite3_step(updateStmt2);
            if (con != SQLITE_DONE) {
                std::cerr << "Insert Execution failed: " << sqlite3_errmsg(db) << std::endl;
                deleteDatabase();
                Globals::instance().leaveAndRet();
            } 
            sqlite3_finalize(updateStmt2);
        }
    }

    if (con != SQLITE_DONE) {
        std::cerr << "Execution failed: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    sqlite3_finalize(stmt);
    sqlite3_close(db);
}

void saveContentsOfDatabase(int id) { 
    sqlite3 *db;
    sqlite3_stmt *stmt;
    char *zErrMsg = 0;
    int con;
    con = sqlite3_open(Globals::instance().filename.c_str(), &db);

    if (con) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    const char *select_sql = "SELECT * FROM SCANS WHERE ID = ?";
    con = sqlite3_prepare_v2(db, select_sql, -1, &stmt, NULL);

    if (con != SQLITE_OK) {
        std::cerr << "Preparation failed: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    sqlite3_bind_int(stmt, 1, id);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int fetchedId = sqlite3_column_int(stmt, 0);
        const unsigned char *ip = sqlite3_column_text(stmt, 1);
        const unsigned char *ports = sqlite3_column_text(stmt, 2);
        const char *convertedPorts = reinterpret_cast<const char *>(ports);

        if (ports) {
            int totalPorts, closedPorts, openPorts;
            getNumberOfPorts(reinterpret_cast<const char*>(ports), totalPorts, closedPorts, openPorts);
            std::cout << "\n\n-----------------------------------------------------------------------------------------------------\n";
            std::cout << "ID = " << fetchedId << "\nIp = " << ip << "\nTotal opened ports: " << openPorts << "\nFound ports: " << ports <<std::endl;
            std::cout << "-----------------------------------------------------------------------------------------------------\n\n";

            numbers[id] = (uint16_t *)malloc((totalPorts - 1) * sizeof(uint16_t));
            std::vector<uint16_t> numbersToSave;
            getNumbers(reinterpret_cast<const char*>(ports), numbersToSave);
            for (size_t i = 0; i < numbersToSave.size() - 1; ++i) {
                numbers[id][i] = numbersToSave[i];
            }
            std::cout << numbers << std::endl;
            std::cout << static_cast<void*>(&Globals::instance().exit);

        }
        else{
            std::cout << "\n\n-----------------------------------------------------------------------------------------------------\n";
            std::cout << "ID = " << fetchedId << "\nIp = " << ip << "\nThere are no opened ports!" << std::endl;
            std::cout << "-----------------------------------------------------------------------------------------------------\n\n";
        }
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);
}

std::string getIpToDelete(int id){
    sqlite3 *db;
    sqlite3_stmt *stmt;
    char *zErrMsg = 0;
    int rc;
    rc = sqlite3_open(Globals::instance().filename.c_str(), &db);

    if (rc) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    const char *select_sql = "SELECT * FROM SCANS WHERE ID = ?";
    rc = sqlite3_prepare_v2(db, select_sql, -1, &stmt, NULL);

    if (rc != SQLITE_OK) {
        std::cerr << "Preparation failed: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    std::string ipToDelete;
    sqlite3_bind_int(stmt, 1, id);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        const unsigned char *ip = sqlite3_column_text(stmt, 1);
        if (ip) {
            ipToDelete = reinterpret_cast<const char *>(ip);
        }

    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);

    return ipToDelete;
}

void deleteContentsOfDatabase(int id){
    sqlite3 *db;
    int con;
    char *zErrMsg = 0;
    const char *sql;
    con = sqlite3_open(Globals::instance().filename.c_str(), &db);

    if (con) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    sqlite3_stmt *stmt;
    const char *deleteSql = "DELETE FROM SCANS WHERE ID = ?";
    con = sqlite3_prepare_v2(db, deleteSql, -1, &stmt, nullptr);
    if (con != SQLITE_OK) {
        std::cerr << "Error preparing statement: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    sqlite3_bind_int(stmt, 1, id);

    con = sqlite3_step(stmt);
    if (con != SQLITE_DONE) {
        std::cerr << "Error executing statement: " << sqlite3_errmsg(db) << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }
    checkMinimalDatabaseID[id] = false;
    free(numbers[id]);
    sqlite3_finalize(stmt);
    sqlite3_close(db);
}