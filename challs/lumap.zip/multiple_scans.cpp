#include "./headers/ping.h"
#include "./headers/db.h"
#include "./headers/multiple_scans.h"
#include "./headers/main.h"

#include <iostream>
#include <vector>
#include <sstream>

std::vector<std::string> usedIPs;
std::string ip;

void saveTheFirstIP(const std::string& oldIpAddress){
    usedIPs.push_back(oldIpAddress);
}

void interface(){
    std::cout << "\n\nYou have made 2 or more scans.\nYou can choose to view any of the previous ones at any moment.\n";

    bool continueTheLoop = true;
    while (true){
        
        std::cout << std::endl << "1) View scans\n2) Delete a scan\n3) Continue scanning\n4) Exit the program\nChoice: ";
        char userChoice;
        std::cin >> userChoice;
        switch (userChoice) {
            case '1':
                std::cout << "Select scan number: ";
                int scanId;
                std::cin >> scanId;
                saveContentsOfDatabase(scanId);
                break;
            case '2':
                std::cout << "Select delete number: ";
                int deleteId;
                std::cin >> deleteId;
                ip = getIpToDelete(deleteId);
                if (!ip.empty())
                    deleteIP(ip, usedIPs);
                deleteContentsOfDatabase(deleteId);
                break;
            case '3':
                continueTheLoop = false;
                multipleScansInterface();
                break;
            case '4':
                std::cout << "Exiting..." << std::endl;
                deleteDatabase();
                Globals::instance().leaveAndRet();
                break;
            default:
                std::cout << "Invalid input." << std::endl;
                deleteDatabase();
                Globals::instance().leaveAndRet();
                break;
        }
    }
}

void multipleScansInterface(){
    std::cout << "Select IP address: ";
    std::string ipAddress;
    std::cin >> ipAddress;
    if (!isValidIpAddress(ipAddress)) {
        std::cout << "It's not a valid IP address." << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    if (checkIfIPUsed(ipAddress, usedIPs)) {
        std::cout << "IP address has been used before." << std::endl;
        deleteDatabase();
        Globals::instance().leaveAndRet();
    } else {
        usedIPs.push_back(ipAddress);
    }
    std::cout << "Selected target: " << ipAddress << std::endl;
    std::string possiblePorts;
    std::cout << "Ports: ";
    std::cin >> possiblePorts;
    if (possiblePorts.find(',') != std::string::npos) {
        std::vector<int> numbers;
        std::stringstream ss(possiblePorts);
        std::string token;
        while (std::getline(ss, token, ',')) {
            numbers.push_back(std::stoi(token));
        }
        std::cout << "Individual ports selected: ";
        for (const auto &num : numbers) {
            std::cout << num << " ";
        }
        std::cout << std::endl;
        int *heapNumbers = new int[numbers.size()];
        for (size_t i = 0; i < numbers.size(); ++i) {
            if (numbers[i] > 65536 || numbers[i] < 0){
                std::cout << "Port number must be in the range 0-65535." << std::endl;
            }
            heapNumbers[i] = numbers[i];
        }
        startTheInitialScanWithMentionedPorts(ipAddress, heapNumbers, numbers.size());

        delete[] heapNumbers;
    }else{
        int portNumber;
        portNumber = std::stoi(possiblePorts);
        if (portNumber < 0 || portNumber > 65536){
            std::cerr << "Port number must be in the range 0-65535." << std::endl;
            deleteDatabase();
            Globals::instance().leaveAndRet();
        }
        std::cout << "Number of ports selected: " << portNumber << std::endl;
        startTheInitialScan(ipAddress, portNumber);
    }

    interface();
}

