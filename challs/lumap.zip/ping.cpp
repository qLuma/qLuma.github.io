#include "./headers/ping.h"
#include "./headers/db.h"
#include "./headers/multiple_scans.h"
#include "./headers/main.h"

#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <sys/fcntl.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

void pingFunction(const std::string& ipAddress, int port, int mentioned){

    struct sockaddr_in targetAddr;
    memset(&targetAddr, 0, sizeof(targetAddr));
    targetAddr.sin_family = AF_INET;
    targetAddr.sin_port = htons(port);
    inet_pton(AF_INET, ipAddress.c_str(), &targetAddr.sin_addr);

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0){
        perror("socket");
        deleteDatabase();
        Globals::instance().leaveAndRet();
    }

    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    int connectionResult = connect(sock, (struct sockaddr *)&targetAddr, sizeof(targetAddr));
    if (connectionResult < 0) {
        if (errno == EINPROGRESS) {
            fd_set fdset;
            struct timeval tv;
            FD_ZERO(&fdset);
            FD_SET(sock, &fdset);
            tv.tv_sec = 0;
            tv.tv_usec = 100000; // 100ms timeout

            if (select(sock + 1, NULL, &fdset, NULL, &tv) == 1) {
                int so_error;
                socklen_t len = sizeof so_error;
                getsockopt(sock, SOL_SOCKET, SO_ERROR, &so_error, &len);
                if (so_error == 0) {
                    std::cout << "Port number "<< port << " is open." << std::endl;
                    includeInDatabase(ipAddress, port, 0);
                }
                else{
                    if (mentioned == 1)
                        includeInDatabase(ipAddress, port, 1);
                }
            }
        }
    }
        close(sock);
        sleep(0.01);
}

int mentioned = 0;
void startTheInitialScan(const std::string& ipAddress, int portNumber) {
    initDatabase(ipAddress);
    for (int i=1; i<=portNumber; i++){
        mentioned = 0;
        pingFunction(ipAddress, i, mentioned);
    }
}

void startTheInitialScanWithMentionedPorts(const std::string& ipAddress, int *numbers, size_t size){
    initDatabase(ipAddress);
    for (int i=0; i<=size; i++){
        mentioned = 1;
        pingFunction(ipAddress, numbers[i], mentioned);
    }
}