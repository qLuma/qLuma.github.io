#ifndef PING_H
#define PING_H

#include <string>

void startTheInitialScan(const std::string& ipAddress, int portNumber);

void startTheInitialScanWithMentionedPorts(const std::string& ipAddress, int *numbers, size_t size);
#endif