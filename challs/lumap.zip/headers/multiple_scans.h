#ifndef MS_H
#define MS_H

#include <string>

void multipleScansInterface();

void saveTheFirstIP(const std::string& oldIpAddress);

#endif