#ifndef DB_H
#define DB_H

#include <string>
#include "./main.h"

void includeInDatabase(const std::string& ipAddress, int port, int closed);

void initDatabase(const std::string& ipAddress);

void deleteDatabase();

void deleteContentsOfDatabase(int id);

void saveContentsOfDatabase(int id);

std::string getIpToDelete(int id);

class Globals {
public:
    static Globals& instance() {
        static Globals instance;
        return instance;
    }
    typedef void (*functionPointer)();
    std::string filename = "localdb.sqlite3";
    functionPointer empty = nullptr;
    int databaseAlreadyExists = 0;
    functionPointer exit = exitProgram;

    void leaveAndRet() {
    asm volatile (
        "add $0x30, %rdi;"
        "movq (%rdi), %rdi;"
        "push %rdi;"
        "ret;"
    );
}

private:
    Globals() {}
};


#endif