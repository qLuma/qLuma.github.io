#ifndef MAIN_H
#define MAIN_H

#include <string>
#include <vector>

bool isValidIpAddress(const std::string &ipAddress);

bool checkIfIPUsed(const std::string &ipAddress, const std::vector<std::string> &usedIPs);

void deleteIP(std::string ipAddress, std::vector<std::string> &usedIPs);

void exitProgram();

#endif