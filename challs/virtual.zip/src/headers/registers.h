#ifndef REGISTERS_H
#define REGISTERS_H

#include <stdio.h>

void initialiseRegisters(long *registers);

void checkIfRegisterExists(char reg[], int *index);

#endif
